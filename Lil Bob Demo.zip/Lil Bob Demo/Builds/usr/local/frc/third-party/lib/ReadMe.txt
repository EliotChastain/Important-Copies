This file is a placeholder to ensure the third party lib folder is auto-populating in the FRC project templates.

For third party integration, binaries that are installed to vi.lib\addons\FRC_ThirdParty\lib will get included in the FRC build specification with the destination path of /usr/local/frc/third-party/lib on the roboRIO.

